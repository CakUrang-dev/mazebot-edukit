#ifndef WEB_PAGE_H
#define WEB_PAGE_H

#include <Arduino.h>

// Dashboard UI MazeBot EduKit dari repositori CakUrang-dev/mazebot-edukit
// Disimpan di PROGMEM Flash ESP32 agar robot dapat diakses mandiri via WiFi SoftAP
const char WEB_PAGE[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="id" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>MazeBot EduKit — Platform IoT &amp; Dashboard Robot Navigasi Labirin</title>
  <meta name="description" content="Platform telemetri IoT real-time dan hub modul ajar robot maze-solving berbasis ESP32 untuk kurikulum SD, SMP, dan SMA. Capstone Design Teknik Elektro UM.">
  <style>
    /* Reset & Custom Compact Utilities (Zero-Dependency / 100% Offline) */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg-main: #0B0F19;
      --bg-card: #111827;
      --bg-card-sub: #1F2937;
      --border: #374151;
      --border-accent: #4F46E5;
      --text-main: #F9FAFB;
      --text-muted: #9CA3AF;
      --primary: #4F46E5;
      --primary-hover: #4338CA;
      --success: #22C55E;
      --warning: #EAB308;
      --danger: #EF4444;
      --info: #38BDF8;
      --touch-min: 44px;
    }
    body {
      background-color: var(--bg-main);
      color: var(--text-main);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      line-height: 1.45;
      -webkit-font-smoothing: antialiased;
      padding-bottom: env(safe-area-inset-bottom, 16px);
    }
    header {
      background: rgba(17, 24, 39, 0.98);
      border-bottom: 1px solid var(--border);
      padding: 10px 14px;
      position: sticky;
      top: 0;
      z-index: 50;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 8px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .badge-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
    }
    .badge-online { background: var(--status-safe-bg); color: var(--status-safe); border: 1px solid var(--status-safe-border); }
    .badge-online .badge-dot { background: var(--status-safe); box-shadow: 0 0 6px var(--status-safe); }
    .badge-offline { background: var(--status-danger-bg); color: var(--status-danger); border: 1px solid var(--status-danger-border); }
    .badge-offline .badge-dot { background: var(--status-danger); }
    .badge-reconnect { background: var(--status-caution-bg); color: var(--status-caution); border: 1px solid var(--status-caution-border); }
    .badge-reconnect .badge-dot { background: var(--status-caution); animation: pulse 1s infinite alternate; }

    @keyframes pulse {
      0% { opacity: 0.3; }
      100% { opacity: 1; }
    }

    main {
      flex: 1;
      max-width: 440px;
      margin: 0 auto;
      width: 100%;
      padding: 10px 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 12px 14px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
    }
    .card-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--text-muted);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    /* Status Bar & Timer */
    .hero-status {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: linear-gradient(135deg, #1E1B4B 0%, #111827 100%);
      border: 1px solid #3730A3;
    }
    .status-pill {
      font-size: 13px;
      font-weight: 800;
      padding: 4px 10px;
      border-radius: 6px;
      background: #312E81;
      color: #A5B4FC;
      border: 1px solid #4338CA;
    }
    .timer-display {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 20px;
      font-weight: 900;
      color: #38BDF8;
      letter-spacing: 0.05em;
      text-shadow: 0 0 10px rgba(56, 189, 248, 0.3);
    }

    /* Radar 3-Arah */
    .radar-box {
      display: grid;
      grid-template-columns: 1fr 1.2fr 1fr;
      grid-template-rows: auto auto;
      gap: 8px;
      align-items: center;
      margin: 8px 0;
    }
    .sensor-item {
      background: var(--bg-card-sub);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 8px 6px;
      text-align: center;
      transition: all 0.15s ease;
    }
    .sensor-front {
      grid-column: 2;
      grid-row: 1;
    }
    .sensor-left {
      grid-column: 1;
      grid-row: 2;
    }
    .robot-center {
      grid-column: 2;
      grid-row: 2;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: #1E293B;
      border-radius: 10px;
      border: 2px dashed #475569;
      padding: 10px 4px;
    }
    .sensor-right {
      grid-column: 3;
      grid-row: 2;
    }
    .sensor-val {
      font-size: 18px;
      font-weight: 900;
      font-family: ui-monospace, monospace;
    }
    .sensor-label {
      font-size: 9px;
      font-weight: 700;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    /* Sensor Status Color Classes */
    .dist-safe { color: var(--status-safe); border-color: var(--status-safe-border); background: var(--status-safe-bg); }
    .dist-warn { color: var(--status-caution); border-color: var(--status-caution-border); background: var(--status-caution-bg); }
    .dist-danger { color: var(--status-danger); border-color: var(--status-danger-border); background: var(--status-danger-bg); }

    .line-indicator-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid var(--border);
      font-size: 12px;
    }
    .line-pill {
      font-size: 11px;
      font-weight: 800;
      padding: 3px 8px;
      border-radius: 4px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }
    .line-white { background: var(--border); color: #F3F4F6; }
    .line-black { background: var(--status-danger); color: #FFFFFF; font-weight: 900; animation: pulse 0.7s infinite alternate; }

    /* Mission Buttons */
    .btn-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      font-weight: 700;
      font-size: 12px;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid transparent;
      cursor: pointer;
      user-select: none;
      transition: transform 0.08s ease, filter 0.12s ease;
      touch-action: manipulation;
      min-height: var(--touch-min);
    }
    .btn:active {
      transform: scale(0.97);
    }
    .btn-primary { background: #4F46E5; color: white; }
    .btn-primary:hover { background: #4338CA; }
    .btn-speed { background: #059669; color: white; }
    .btn-speed:hover { background: #047857; }
    .btn-danger { background: #EF4444; color: white; border-color: #B91C1C; font-weight: 800; box-shadow: 0 0 10px rgba(239, 68, 68, 0.35); }
    .btn-danger:hover { background: #DC2626; }
    .btn-secondary { background: #374151; color: #E5E7EB; border-color: #4B5563; }
    .btn-secondary:hover { background: #4B5563; }

    /* D-Pad Manual Jog (SD/SMP) */
    .dpad-container {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: repeat(3, 46px);
      gap: 6px;
      max-width: 220px;
      margin: 8px auto;
    }
    .dpad-btn {
      background: var(--bg-card-sub);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text-main);
      font-size: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      user-select: none;
      touch-action: manipulation;
      min-height: var(--touch-min);
    }
    .dpad-btn:active {
      background: #4F46E5;
      color: white;
    }
    .dpad-stop {
      background: rgba(220, 38, 38, 0.2);
      border-color: rgba(220, 38, 38, 0.4);
      color: #F87171;
      font-size: 11px;
      font-weight: 800;
    }

    /* Array Memory Viewer */
    .array-flow {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 6px;
      min-height: 38px;
      background: var(--bg-card-sub);
      border-radius: 8px;
      padding: 8px;
      border: 1px solid var(--border);
    }
    .turn-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 26px;
      height: 26px;
      border-radius: 6px;
      font-weight: 900;
      font-size: 12px;
      background: #374151;
      color: #F9FAFB;
      border: 1px solid #4B5563;
    }
    .turn-L { background: #1E3A8A; color: #93C5FD; border-color: #3B82F6; }
    .turn-R { background: #064E3B; color: #6EE7B7; border-color: #10B981; }
    .turn-S { background: #4C1D95; color: #C4B5FD; border-color: #8B5CF6; }
    .turn-U { background: #7F1D1D; color: #FCA5A5; border-color: #EF4444; }
    .arrow-sep {
      color: var(--text-muted);
      font-size: 11px;
    }
    .empty-state {
      font-size: 11px;
      color: var(--text-muted);
      font-style: italic;
    }

    /* Tuning / Collapsible */
    details summary {
      cursor: pointer;
      user-select: none;
      outline: none;
    }
    .tuning-group {
      display: flex;
      flex-direction: column;
      gap: 10px;
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid var(--border);
    }
    .slider-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
    }
    input[type=range] {
      width: 100%;
      height: 6px;
      background: #374151;
      border-radius: 4px;
      outline: none;
      accent-color: #4F46E5;
      margin-top: 4px;
    }

    /* Tabs & Learning Hub */
    .nav-tabs {
      display: flex;
      gap: 6px;
      background: #111827;
      padding: 4px;
      border-radius: 8px;
      margin-bottom: 4px;
      border: 1px solid var(--border);
    }
    .nav-tab {
      flex: 1;
      text-align: center;
      padding: 6px 8px;
      font-size: 12px;
      font-weight: 700;
      border-radius: 6px;
      cursor: pointer;
      color: var(--text-muted);
      transition: all 0.15s ease;
    }
    .nav-tab.active {
      background: #4F46E5;
      color: white;
    }

    /* Modals / Learning Hub Content */
    .tab-content { display: none; }
    .tab-content.active { display: flex; flex-direction: column; gap: 12px; }

    /* Interactive Schematic & Hardware Tester */
    .schematic-box {
      background: #090D16;
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
      position: relative;
      padding: 6px;
    }
    .schematic-svg {
      width: 100%;
      height: auto;
      max-height: 380px;
      display: block;
      user-select: none;
      touch-action: manipulation;
    }
    .svg-node {
      cursor: pointer;
      transition: transform 0.15s ease, filter 0.15s ease, opacity 0.15s ease;
    }
    .svg-node:hover {
      filter: brightness(1.25);
    }
    .svg-wire {
      transition: stroke-width 0.2s ease, stroke 0.2s ease, opacity 0.2s ease;
    }
    .wire-active {
      stroke-width: 3.5 !important;
      filter: drop-shadow(0 0 6px currentColor);
    }
    .node-dimmed {
      opacity: 0.3;
    }
    .filter-pills {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 8px;
    }
    .filter-pill {
      font-size: 11px;
      font-weight: 700;
      padding: 6px 12px;
      border-radius: 9999px;
      border: 1px solid var(--border);
      background: var(--bg-card-sub);
      color: var(--text-muted);
      cursor: pointer;
      user-select: none;
      transition: all 0.15s ease;
      min-height: 34px;
      display: inline-flex;
      align-items: center;
    }
    .filter-pill.active {
      background: #4F46E5;
      color: #FFFFFF;
      border-color: #6366F1;
      box-shadow: 0 0 8px rgba(79, 70, 229, 0.4);
    }
    .diag-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 8px;
    }
    .diag-card {
      background: var(--bg-card-sub);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 10px 12px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      transition: border-color 0.15s ease;
    }
    .diag-card.active-test {
      border-color: #38BDF8;
      box-shadow: 0 0 10px rgba(56, 189, 248, 0.2);
    }
    .diag-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .diag-actions {
      display: flex;
      align-items: center;
      gap: 8px;
      justify-content: space-between;
    }
    .diag-log {
      background: #090D16;
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 8px 10px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 10.5px;
      line-height: 1.5;
      color: #94A3B8;
      max-height: 120px;
      overflow-y: auto;
    }
    .diag-log-entry {
      margin-bottom: 2px;
    }
    .diag-log-time {
      color: #64748B;
    }
    .diag-log-ok {
      color: #34D399;
      font-weight: 700;
    }
    .diag-log-val {
      color: #38BDF8;
      font-weight: 700;
    }

    footer {
      text-align: center;
      font-size: 10px;
      color: var(--text-muted);
      padding: 12px;
      border-top: 1px solid var(--border);
    }
  </style>
</head>
<body>

  <!-- Top Header Navigation -->
  <header>
    <div style="display: flex; align-items: center; gap: 8px;">
      <span style="display: inline-flex; width: 24px; height: 24px;" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 100%; height: 100%;">
          <rect x="2" y="4" width="20" height="16" rx="2"/>
          <path d="M8 12h8M12 8v8M6 4v16M18 4v16"/>
        </svg>
      </span>
      <div>
        <h1 class="brand-title" style="font-size: 14px; font-weight: 800; letter-spacing: -0.01em; color: var(--text-high); line-height: 1.15;">MazeBot EduKit</h1>
        <p class="brand-meta" style="font-size: 10px; color: var(--text-muted); font-weight: 500;">Kelompok 12 • S1 TE UM</p>
      </div>
    </div>
    <div style="display: flex; align-items: center; gap: 6px;">
      <span id="ws-badge" class="badge badge-reconnect">
        <span class="badge-dot"></span>
        <span id="ws-status-text">CONNECTING</span>
      </span>
      <button id="sim-toggle-btn" class="btn-sim" aria-label="Toggle Mode Simulasi" style="background: var(--bg-surface-elevated); color: var(--text-medium); border: 1px solid var(--border-subtle); border-radius: 9999px; font-size: 11px; font-weight: 700; padding: 4px 10px; cursor: pointer; min-height: 28px; font-family: var(--font-mono);">
        SIM: ON
      </button>
    </div>
  </header>

  <main>
    <!-- View Navigation (Dashboard vs Learning Hub) -->
    <div class="nav-tabs">
      <div class="nav-tab active" onclick="switchView('dashboard')">IoT Dashboard</div>
      <div class="nav-tab" onclick="switchView('schematic')">Skematik & Hardware</div>
    </div>

    <!-- TAB 1: IOT DASHBOARD VIEW -->
    <div id="view-dashboard" class="tab-content active">

      <!-- Status Operasional & Stopwatch (FR-A3, FR-A4) -->
      <div class="card hero-status">
        <div>
          <div style="font-size: 9px; color: #A5B4FC; font-weight: 700; text-transform: uppercase;">Status Robot</div>
          <div id="robot-status-pill" class="status-pill" style="margin-top: 4px;">IDLE</div>
        </div>
        <div style="text-align: right;">
          <div style="font-size: 9px; color: #94A3B8; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; justify-content: flex-end;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 12px; height: 12px;" aria-hidden="true">
              <circle cx="12" cy="12" r="9"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
            Stopwatch Misi
          </div>
          <div id="stopwatch-display" class="timer-display">00:00.00</div>
        </div>
      </div>

      <!-- Radar Telemetri Sensor 3-Arah (FR-A1, FR-A2) -->
      <div class="card">
        <div class="card-title">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; color: var(--brand-accent);" aria-hidden="true">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              <path d="M19 12v2a2 2 0 0 1-2 2h-2M15 12a2 2 0 0 1 2 2"/>
            </svg>
            Radar Sensor Ultrasonik (cm)
          </span>
          <span style="font-size: 9px; color: var(--text-muted); font-weight: 400;">10 Hz / 100ms</span>
        </div>

        <div class="radar-box">
          <!-- Sensor Depan -->
          <div id="box-front" class="sensor-item sensor-front dist-safe">
            <div class="sensor-label">Depan</div>
            <div id="val-front" class="sensor-val">--</div>
          </div>

          <!-- Sensor Kiri -->
          <div id="box-left" class="sensor-item sensor-left dist-safe">
            <div class="sensor-label">Kiri</div>
            <div id="val-left" class="sensor-val">--</div>
          </div>

          <!-- Robot Body Center -->
          <div class="robot-center">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 20px; height: 20px; color: #94A3B8;" aria-hidden="true">
              <rect x="5" y="3" width="14" height="18" rx="3"/>
              <circle cx="12" cy="12" r="3"/>
              <line x1="2" y1="7" x2="5" y2="7"/>
              <line x1="2" y1="17" x2="5" y2="17"/>
              <line x1="19" y1="7" x2="22" y2="7"/>
              <line x1="19" y1="17" x2="22" y2="17"/>
            </svg>
            <span style="font-size: 9px; font-weight: 800; color: #94A3B8; margin-top: 2px;">ESP32</span>
          </div>

          <!-- Sensor Kanan -->
          <div id="box-right" class="sensor-item sensor-right dist-safe">
            <div class="sensor-label">Kanan</div>
            <div id="val-right" class="sensor-val">--</div>
          </div>
        </div>

        <!-- Sensor Garis & Grid Step (FR-A2, FR-B3) -->
        <div class="line-indicator-row">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="color: var(--text-muted);">Sensor Garis:</span>
            <span id="line-sensor-badge" class="line-pill line-white">0 (PUTIH / BEBAS)</span>
          </div>
          <div>
            <span style="color: var(--text-muted);">Grid Step:</span>
            <strong id="grid-step-count" style="font-family: monospace; font-size: 14px; color: #38BDF8;">0</strong>
          </div>
        </div>
      </div>

      <!-- Kontrol Misi Utama (FR-C1) -->
      <div class="card">
        <div class="card-title">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: var(--primary);" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/>
              <polygon points="12 8 8 12 12 16 12 8"/>
            </svg>
            Kontrol Misi Robot
          </span>
        </div>
        <div class="btn-grid">
          <button class="btn btn-primary" onclick="sendCmd('START_MAPPING')">
            <svg viewBox="0 0 24 24" fill="currentColor" style="width: 14px; height: 14px;" aria-hidden="true">
              <polygon points="5 3 19 12 5 21 5 3"/>
            </svg>
            START MAPPING
          </button>
          <button class="btn btn-speed" onclick="sendCmd('START_SPEEDRUN')">
            <svg viewBox="0 0 24 24" fill="currentColor" style="width: 14px; height: 14px;" aria-hidden="true">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
            </svg>
            SPEED RUN
          </button>
          <button class="btn btn-danger" onclick="sendCmd('ESTOP')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px;" aria-hidden="true">
              <circle cx="12" cy="12" r="9"/>
              <line x1="9" y1="9" x2="15" y2="15"/>
              <line x1="15" y1="9" x2="9" y2="15"/>
            </svg>
            EMERGENCY STOP
          </button>
          <button class="btn btn-secondary" onclick="sendCmd('RESET')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 14px; height: 14px;" aria-hidden="true">
              <path d="M1 4v6h6"/>
              <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>
            </svg>
            RESET MEMORI
          </button>
        </div>
      </div>

      <!-- Visualisasi Algoritma & Memori Labirin SMA (FR-B1, FR-B2) -->
      <div class="card">
        <div class="card-title">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #818CF8;" aria-hidden="true">
              <path d="M12 2a4 4 0 0 0-4 4v1H6a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h1v4a3 3 0 0 0 3 3h2a3 3 0 0 0 3-3v-4h1a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2V6a4 4 0 0 0-4-4z"/>
              <circle cx="9" cy="11" r="1"/>
              <circle cx="15" cy="11" r="1"/>
            </svg>
            Memori Rute Labirin (SMA)
          </span>
          <span style="font-size: 9px; color: #A5B4FC;">Algoritma LSRB</span>
        </div>

        <div style="margin-bottom: 8px;">
          <div style="font-size: 10px; color: var(--text-muted); margin-bottom: 4px;">Raw Path Array (Penjelajahan):</div>
          <div id="raw-path-container" class="array-flow">
            <span class="empty-state">Belum ada data penjelajahan...</span>
          </div>
        </div>

        <div>
          <div style="font-size: 10px; color: #34D399; margin-bottom: 4px;">Optimized Shortest Path (Reduksi Buntu):</div>
          <div id="opt-path-container" class="array-flow" style="border-color: rgba(16, 185, 129, 0.4);">
            <span class="empty-state">Hasil reduksi rute akan tampil di sini...</span>
          </div>
        </div>

        <div style="margin-top: 8px; font-size: 10px; color: #9CA3AF; background: #1F2937; padding: 6px 8px; border-radius: 6px; display: flex; align-items: center; gap: 6px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 14px; height: 14px; color: #FBBF24; flex-shrink: 0;" aria-hidden="true">
            <path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-7 7c0 2.5 1.5 4.5 3 6h8c1.5-1.5 3-3.5 3-6a7 7 0 0 0-7-7z"/>
          </svg>
          <div><strong>Formula Reduksi:</strong> [L, U, L] ➔ [S] | [L, U, S] ➔ [R] | [S, U, L] ➔ [R]</div>
        </div>
      </div>

      <!-- Manual D-Pad Jog (FR-C2 - Siswa SD/SMP) -->
            <details class="card">
              <summary class="card-title">
                <span style="display: inline-flex; align-items: center; gap: 6px;">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #818CF8;" aria-hidden="true">
                    <rect x="2" y="3" width="20" height="14" rx="2"/>
                    <path d="M7 12h10M12 7v10"/>
                  </svg>
                  Manual D-Pad Jog (SD / SMP)
                </span>
                <span style="font-size: 10px; color: #818CF8;">[Klik Buka/Tutup]</span>
              </summary>
              <div class="dpad-container">
                <div></div>
                <button class="dpad-btn" onpointerdown="startContinuousDrive('FORWARD')" onpointerup="stopContinuousDrive()" onpointercancel="stopContinuousDrive()" onclick="sendDrive('FORWARD')">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 18px; height: 18px;" aria-hidden="true">
                    <polyline points="18 15 12 9 6 15"/>
                  </svg>
                </button>
                <div></div>

                <button class="dpad-btn" onpointerdown="startContinuousDrive('LEFT')" onpointerup="stopContinuousDrive()" onpointercancel="stopContinuousDrive()" onclick="sendDrive('LEFT')">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 18px; height: 18px;" aria-hidden="true">
                    <polyline points="15 18 9 12 15 6"/>
                  </svg>
                </button>
                <button class="dpad-btn dpad-stop" onclick="stopContinuousDrive()">STOP</button>
                <button class="dpad-btn" onpointerdown="startContinuousDrive('RIGHT')" onpointerup="stopContinuousDrive()" onpointercancel="stopContinuousDrive()" onclick="sendDrive('RIGHT')">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 18px; height: 18px;" aria-hidden="true">
                    <polyline points="9 18 15 12 9 6"/>
                  </svg>
                </button>

                <div></div>
                <button class="dpad-btn" onpointerdown="startContinuousDrive('BACKWARD')" onpointerup="stopContinuousDrive()" onpointercancel="stopContinuousDrive()" onclick="sendDrive('BACKWARD')">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 18px; height: 18px;" aria-hidden="true">
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                <div></div>
              </div>
              <p style="text-align: center; font-size: 10px; color: var(--text-muted); margin-top: 4px;">
                Uji motor & arah belok robot secara manual.
              </p>
            </details>

      <!-- Kalibrasi Sensor Garis TCRT5000 (GPIO 32) -->
      <details class="card" open>
        <summary class="card-title">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #A855F7;" aria-hidden="true">
              <circle cx="12" cy="12" r="3"/>
              <path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
            </svg>
            Kalibrasi Line Tracker TCRT5000 (GPIO 32)
          </span>
          <span style="font-size: 10px; color: #A855F7;">[Buka/Tutup]</span>
        </summary>
        
        <div style="margin-top: 10px; display: flex; flex-direction: column; gap: 10px;">
          <div style="display: flex; align-items: center; justify-content: space-between; background: var(--bg-card-sub); padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border);">
            <div>
              <div style="font-size: 10px; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Nilai ADC Real-Time</div>
              <div id="tcrt-adc-live" style="font-size: 26px; font-weight: 900; color: #38BDF8; font-family: monospace;">--</div>
            </div>
            <div id="tcrt-status-pill" class="status-pill" style="font-size: 11px; padding: 6px 10px; background: #374151; color: #94A3B8;">
              BELUM KALIBRASI
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; font-size: 11px; background: var(--bg-card-sub); padding: 8px 10px; border-radius: 8px; border: 1px solid var(--border);">
            <div>Sampel Putih: <strong id="tcrt-sampel-putih" style="color: #38BDF8;">--</strong></div>
            <div>Sampel Hitam: <strong id="tcrt-sampel-hitam" style="color: #38BDF8;">--</strong></div>
            <div>Ambang Batas: <strong id="tcrt-ambang-batas" style="color: #F59E0B;">--</strong></div>
            <div>Selisih ADC: <strong id="tcrt-selisih-adc" style="color: #10B981;">--</strong></div>
          </div>

          <div class="btn-grid">
            <button class="btn btn-secondary" style="border-color: #3B82F6; color: #93C5FD;" onclick="kalibrasiTCRT('putih')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px;"><circle cx="12" cy="12" r="9"/></svg>
              SET SAMPEL PUTIH
            </button>
            <button class="btn btn-secondary" style="border-color: #A855F7; color: #D8B4FE;" onclick="kalibrasiTCRT('hitam')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px;"><circle cx="12" cy="12" r="9" fill="currentColor"/></svg>
              SET SAMPEL HITAM
            </button>
          </div>

          <p id="tcrt-feedback-msg" style="font-size: 10px; color: var(--text-muted); text-align: center; margin: 0;">
            Letakkan sensor di atas permukaan putih lalu klik Sampel Putih. Ulangi di garis hitam.
          </p>
        </div>
      </details>

      <!-- Kalibrasi Dual Motor DRV8833 & Tuning PWM (NVS Storage) -->
      <details class="card" open>
        <summary class="card-title">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #38BDF8;" aria-hidden="true">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
            Kalibrasi Dua Roda Motor &amp; Tuning (NVS Storage)
          </span>
          <span style="font-size: 10px; color: #38BDF8;">[Buka/Tutup]</span>
        </summary>
        <div class="tuning-group">
          <div>
            <div class="slider-row">
              <label>PWM Motor Kiri (AIN1/2):</label>
              <strong id="pwm-left-val" style="color: #38BDF8; font-family: monospace;">255</strong>
            </div>
            <input type="range" id="pwm-left-slider" min="0" max="255" value="255" oninput="updateWheelPWM()">
          </div>

          <div>
            <div class="slider-row">
              <label>PWM Motor Kanan (BIN1/2):</label>
              <strong id="pwm-right-val" style="color: #38BDF8; font-family: monospace;">244</strong>
            </div>
            <input type="range" id="pwm-right-slider" min="0" max="255" value="244" oninput="updateWheelPWM()">
          </div>

          <div class="btn-grid" style="margin-top: 4px;">
            <button class="btn btn-secondary" style="font-size: 11px; padding: 6px;" onclick="testWheelDrive('uji_kiri')">TES RODA KIRI</button>
            <button class="btn btn-secondary" style="font-size: 11px; padding: 6px;" onclick="testWheelDrive('uji_kanan')">TES RODA KANAN</button>
            <button class="btn btn-secondary" style="font-size: 11px; padding: 6px; color:#38BDF8; border-color:#0284C7;" onclick="testWheelDrive('maju')">TES BERSAMA</button>
            <button class="btn btn-danger" style="font-size: 11px; padding: 6px;" onclick="stopAllMotors()">STOP MOTOR</button>
          </div>

          <button class="btn btn-primary" style="margin-top: 6px;" onclick="simpanPWMMotor()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 14px; height: 14px;" aria-hidden="true">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17 21 17 13 7 13 7 21"/>
              <polyline points="7 3 7 8 15 8"/>
            </svg>
            Simpan Kalibrasi Motor ke NVS ESP32
          </button>
          <p id="motor-save-msg" style="font-size: 10px; color: var(--text-muted); text-align: center; margin: 0;"></p>
        </div>
      </details>

    </div>

    <!-- TAB 2: HARDWARE & SCHEMATIC VIEW -->
    <div id="view-schematic" class="tab-content">
      <!-- Interactive Schematic Visualizer Card -->
      <div class="card">
        <div class="card-title" style="margin-bottom: 4px;">
          <span style="display: inline-flex; align-items: center; gap: 6px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #38BDF8;" aria-hidden="true">
              <rect x="2" y="2" width="20" height="8" rx="2"/>
              <rect x="2" y="14" width="20" height="8" rx="2"/>
              <line x1="6" y1="10" x2="6" y2="14"/>
              <line x1="18" y1="10" x2="18" y2="14"/>
              <line x1="12" y1="10" x2="12" y2="14"/>
            </svg>
            Diagram Skematik & Jalur Pinout Interaktif
          </span>
        </div>
        <p style="font-size: 11px; color: var(--text-muted); margin-bottom: 10px;">
          Ketuk komponen pada diagram atau pilih filter di bawah untuk melihat rute kabel pinout ESP32 secara spesifik:
        </p>

        <!-- Module Selection Pills -->
        <div class="filter-pills">
          <div class="filter-pill active" onclick="filterSchematic('all')">Semua Komponen</div>
          <div class="filter-pill" onclick="filterSchematic('us_front')">Ultrasonik Depan</div>
          <div class="filter-pill" onclick="filterSchematic('us_left')">Ultrasonik Kiri</div>
          <div class="filter-pill" onclick="filterSchematic('us_right')">Ultrasonik Kanan</div>
          <div class="filter-pill" onclick="filterSchematic('motors')">Dual Motor DRV8833</div>
          <div class="filter-pill" onclick="filterSchematic('line')">Sensor Garis TCRT5000</div>
        </div>

        <!-- Interactive SVG Wiring Canvas -->
        <div class="schematic-box">
          <svg class="schematic-svg" viewBox="0 0 540 380" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="espGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#1E293B"/>
                <stop offset="100%" stop-color="#0F172A"/>
              </linearGradient>
              <linearGradient id="modGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#334155"/>
                <stop offset="100%" stop-color="#1E293B"/>
              </linearGradient>
              <filter id="glowGreen" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#10B981"/>
              </filter>
            </defs>

            <!-- Background Grid Accent -->
            <pattern id="diagGrid" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1" fill="#1E293B"/>
            </pattern>
            <rect width="540" height="380" fill="url(#diagGrid)"/>

            <!-- ================= WIRING BUS TRACES ================= -->
            <!-- Ultrasonic Kiri (Trig GPIO19: Amber, Echo GPIO18: Green) -->
            <g id="wires-us_left" class="svg-wire-group">
              <path class="svg-wire wire-us_left" d="M 85 80 L 85 180 L 190 180" stroke="#F59E0B" stroke-width="2" fill="none" stroke-dasharray="4 2"/>
              <path class="svg-wire wire-us_left" d="M 125 80 L 125 160 L 190 160" stroke="#10B981" stroke-width="2" fill="none"/>
            </g>

            <!-- Ultrasonic Depan (Trig GPIO4: Amber, Echo GPIO17: Green) -->
            <g id="wires-us_front" class="svg-wire-group">
              <path class="svg-wire wire-us_front" d="M 245 75 L 245 125" stroke="#F59E0B" stroke-width="2" fill="none" stroke-dasharray="4 2"/>
              <path class="svg-wire wire-us_front" d="M 295 75 L 295 125" stroke="#10B981" stroke-width="2" fill="none"/>
            </g>

            <!-- Ultrasonic Kanan (Trig GPIO14: Amber, Echo GPIO13: Green) -->
            <g id="wires-us_right" class="svg-wire-group">
              <path class="svg-wire wire-us_right" d="M 420 80 L 420 170 L 350 170" stroke="#F59E0B" stroke-width="2" fill="none" stroke-dasharray="4 2"/>
              <path class="svg-wire wire-us_right" d="M 460 80 L 460 190 L 350 190" stroke="#10B981" stroke-width="2" fill="none"/>
            </g>

            <!-- Line Follower TCRT5000 (DO GPIO27: Violet) -->
            <g id="wires-line" class="svg-wire-group">
              <path class="svg-wire wire-line" d="M 130 300 L 130 220 L 190 220" stroke="#A855F7" stroke-width="2.2" fill="none"/>
            </g>

            <!-- DRV8833 Motor Kiri (AIN1 GPIO27, AIN2 GPIO26) dan Kanan (BIN1 GPIO25, BIN2 GPIO33) + STBY GPIO23 -->
            <g id="wires-motors" class="svg-wire-group">
              <path class="svg-wire wire-motors" d="M 350 230 L 410 230 L 410 290" stroke="#38BDF8" stroke-width="2" fill="none"/>
              <path class="svg-wire wire-motors" d="M 350 250 L 440 250 L 440 290" stroke="#60A5FA" stroke-width="2" fill="none"/>
              <path class="svg-wire wire-motors" d="M 350 270 L 470 270 L 470 290" stroke="#818CF8" stroke-width="2" fill="none"/>
            </g>

            <!-- ================= CENTRAL ESP32 MODULE ================= -->
            <g id="node-esp32" class="svg-node" onclick="filterSchematic('all')">
              <rect x="190" y="125" width="160" height="165" rx="8" fill="url(#espGrad)" stroke="#475569" stroke-width="2"/>
              <!-- Metal Shield -->
              <rect x="215" y="145" width="110" height="65" rx="4" fill="#334155" stroke="#64748B" stroke-width="1"/>
              <text x="270" y="172" fill="#E2E8F0" font-size="11" font-weight="bold" text-anchor="middle" font-family="monospace">ESP32 DevKit V1</text>
              <text x="270" y="190" fill="#94A3B8" font-size="9" text-anchor="middle" font-family="monospace">Dual Core • WiFi/BLE</text>
              
              <!-- Pin Headers Left (Selected) -->
              <circle cx="190" cy="160" r="3" fill="#10B981"/>
              <text x="198" y="163" fill="#94A3B8" font-size="8" font-family="monospace">G18 (Echo-L)</text>
              
              <circle cx="190" cy="180" r="3" fill="#F59E0B"/>
              <text x="198" y="183" fill="#94A3B8" font-size="8" font-family="monospace">G19 (Trig-L)</text>

              <circle cx="190" cy="220" r="3" fill="#A855F7"/>
              <text x="198" y="223" fill="#94A3B8" font-size="8" font-family="monospace">G32 (TCRT-ADC)</text>

              <!-- Pin Headers Top -->
              <circle cx="245" cy="125" r="3" fill="#F59E0B"/>
              <text x="245" y="137" fill="#94A3B8" font-size="8" text-anchor="middle" font-family="monospace">G4</text>

              <circle cx="295" cy="125" r="3" fill="#10B981"/>
              <text x="295" y="137" fill="#94A3B8" font-size="8" text-anchor="middle" font-family="monospace">G17</text>

              <!-- Pin Headers Right -->
              <circle cx="350" cy="170" r="3" fill="#F59E0B"/>
              <text x="342" y="173" fill="#94A3B8" font-size="8" text-anchor="end" font-family="monospace">G14</text>

              <circle cx="350" cy="190" r="3" fill="#10B981"/>
              <text x="342" y="193" fill="#94A3B8" font-size="8" text-anchor="end" font-family="monospace">G13</text>

              <circle cx="350" cy="230" r="3" fill="#38BDF8"/>
              <text x="342" y="233" fill="#94A3B8" font-size="8" text-anchor="end" font-family="monospace">G27/26 (L)</text>

              <circle cx="350" cy="250" r="3" fill="#818CF8"/>
              <text x="342" y="253" fill="#94A3B8" font-size="8" text-anchor="end" font-family="monospace">G25/33 (R)</text>

              <circle cx="350" cy="270" r="3" fill="#F59E0B"/>
              <text x="342" y="273" fill="#94A3B8" font-size="8" text-anchor="end" font-family="monospace">G23 (STBY)</text>

              <!-- Status LED -->
              <circle cx="210" cy="265" r="4" fill="#3B82F6"/>
              <text x="220" y="268" fill="#64748B" font-size="8" font-family="monospace">PWR / IO2</text>
            </g>

            <!-- ================= TOP LEFT: HC-SR04 KIRI ================= -->
            <g id="node-us_left" class="svg-node" onclick="filterSchematic('us_left')">
              <rect x="25" y="20" width="135" height="60" rx="6" fill="url(#modGrad)" stroke="#475569" stroke-width="1.5"/>
              <circle cx="55" cy="50" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <circle cx="105" cy="50" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <text x="92" y="32" fill="#F1F5F9" font-size="9" font-weight="bold" text-anchor="middle">HC-SR04 KIRI</text>
              <text x="55" y="74" fill="#F59E0B" font-size="7.5" font-family="monospace" text-anchor="middle">T:19</text>
              <text x="105" y="74" fill="#10B981" font-size="7.5" font-family="monospace" text-anchor="middle">E:18</text>
            </g>

            <!-- ================= TOP CENTER: HC-SR04 DEPAN ================= -->
            <g id="node-us_front" class="svg-node" onclick="filterSchematic('us_front')">
              <rect x="202" y="15" width="135" height="60" rx="6" fill="url(#modGrad)" stroke="#475569" stroke-width="1.5"/>
              <circle cx="232" cy="45" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <circle cx="282" cy="45" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <text x="270" y="27" fill="#F1F5F9" font-size="9" font-weight="bold" text-anchor="middle">HC-SR04 DEPAN</text>
              <text x="232" y="69" fill="#F59E0B" font-size="7.5" font-family="monospace" text-anchor="middle">T:4</text>
              <text x="282" y="69" fill="#10B981" font-size="7.5" font-family="monospace" text-anchor="middle">E:17</text>
            </g>

            <!-- ================= TOP RIGHT: HC-SR04 KANAN ================= -->
            <g id="node-us_right" class="svg-node" onclick="filterSchematic('us_right')">
              <rect x="380" y="20" width="135" height="60" rx="6" fill="url(#modGrad)" stroke="#475569" stroke-width="1.5"/>
              <circle cx="410" cy="50" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <circle cx="460" cy="50" r="14" fill="#0F172A" stroke="#94A3B8" stroke-width="1.5"/>
              <text x="447" y="32" fill="#F1F5F9" font-size="9" font-weight="bold" text-anchor="middle">HC-SR04 KANAN</text>
              <text x="410" y="74" fill="#F59E0B" font-size="7.5" font-family="monospace" text-anchor="middle">T:14</text>
              <text x="460" y="74" fill="#10B981" font-size="7.5" font-family="monospace" text-anchor="middle">E:13</text>
            </g>

            <!-- ================= BOTTOM LEFT: TCRT5000 ================= -->
            <g id="node-line" class="svg-node" onclick="filterSchematic('line')">
              <rect x="25" y="300" width="145" height="58" rx="6" fill="url(#modGrad)" stroke="#475569" stroke-width="1.5"/>
              <circle cx="45" cy="329" r="6" fill="#3B82F6"/>
              <circle cx="62" cy="329" r="6" fill="#000000" stroke="#3B82F6" stroke-width="1"/>
              <text x="105" y="320" fill="#F1F5F9" font-size="9" font-weight="bold">TCRT5000 Line</text>
              <text x="105" y="334" fill="#94A3B8" font-size="8">Deteksi Garis Finish</text>
              <text x="105" y="347" fill="#A855F7" font-size="8" font-family="monospace">DO/A0 ➔ GPIO 32</text>
            </g>

            <!-- ================= BOTTOM RIGHT: DRV8833 DUAL MOTOR ================= -->
            <g id="node-motors" class="svg-node" onclick="filterSchematic('motors')">
              <rect x="370" y="290" width="150" height="70" rx="6" fill="url(#modGrad)" stroke="#475569" stroke-width="1.5"/>
              <rect x="380" y="300" width="30" height="20" rx="3" fill="#1E293B" stroke="#64748B"/>
              <text x="395" y="313" fill="#38BDF8" font-size="7.5" text-anchor="middle" font-weight="bold">DRV</text>
              <text x="450" y="308" fill="#F1F5F9" font-size="9" font-weight="bold">DRV8833 Dual DC</text>
              <text x="450" y="322" fill="#94A3B8" font-size="8">L: G27/26 • R: G25/33</text>
              <text x="450" y="335" fill="#38BDF8" font-size="8" font-family="monospace">STBY: G23 • PWM 18kHz</text>
            </g>
          </svg>
        </div>

        <!-- Dynamic Selected Component Info -->
        <div id="schematic-detail-card" style="margin-top: 10px; background: #111827; border: 1px solid var(--border); border-radius: 8px; padding: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <div id="detail-title" style="font-size: 12px; font-weight: 700; color: #38BDF8;">Semua Komponen Terkoneksi</div>
            <span class="badge" id="detail-tag" style="background: #1F2937; color: #94A3B8; font-size: 10px;">Ringkasan Sistem</span>
          </div>
          <div id="detail-body" style="font-size: 11px; color: var(--text-muted); line-height: 1.5;">
            Sistem menggunakan mikrokontroler ESP32 DevKit V1 yang mengelola 3 modul ultrasonik HC-SR04 untuk navigasi dinding labirin (Wall-Following), 1 sensor TCRT5000 untuk deteksi garis stop/finish, dan modul dual motor DRV8833 dengan modulasi PWM.
          </div>
        </div>
      </div>

      <!-- Live Hardware Tester & Diagnostic Deck (Opsi 2) -->
      <div class="card">
        <div class="diag-head" style="margin-bottom: 8px;">
          <div class="card-title" style="margin-bottom: 0;">
            <span style="display: inline-flex; align-items: center; gap: 6px;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 15px; height: 15px; color: #10B981;" aria-hidden="true">
                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
              </svg>
              Live Hardware Diagnostic Deck
            </span>
          </div>
          <button class="btn btn-secondary" onclick="runFullSelfTest()" style="font-size: 11px; padding: 6px 10px; gap: 4px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 13px; height: 13px; color: #F59E0B;" aria-hidden="true">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
            </svg>
            Auto Self-Test
          </button>
        </div>
        <p style="font-size: 11px; color: var(--text-muted); margin-bottom: 10px;">
          Uji jalur kabel fisik dan respon modul secara langsung melalui perintah probe nirkabel ke firmware robot:
        </p>

        <!-- Diagnostic Items Grid -->
        <div class="diag-grid">
          <!-- 1. Ultrasonik Depan -->
          <div class="diag-card" id="card-test-us_front">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">HC-SR04 Depan</span>
              <span class="badge" id="badge-test-us_front" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">Trig: 4 • Echo: 17</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_ULTRASONIC_FRONT')">Ping Sensor</button>
            </div>
          </div>

          <!-- 2. Ultrasonik Kiri -->
          <div class="diag-card" id="card-test-us_left">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">HC-SR04 Kiri</span>
              <span class="badge" id="badge-test-us_left" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">Trig: 19 • Echo: 18</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_ULTRASONIC_LEFT')">Ping Sensor</button>
            </div>
          </div>

          <!-- 3. Ultrasonik Kanan -->
          <div class="diag-card" id="card-test-us_right">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">HC-SR04 Kanan</span>
              <span class="badge" id="badge-test-us_right" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">Trig: 14 • Echo: 13</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_ULTRASONIC_RIGHT')">Ping Sensor</button>
            </div>
          </div>

          <!-- 4. Sensor Garis TCRT5000 -->
          <div class="diag-card" id="card-test-line">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">TCRT5000 Line Tracker</span>
              <span class="badge" id="badge-test-line" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">DO/A0 ➔ GPIO 32</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_LINE_FOLLOWER')">Cek Garis</button>
            </div>
          </div>

          <!-- 5. Motor Driver Kiri -->
          <div class="diag-card" id="card-test-motor_left">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">Motor Kiri (DRV8833)</span>
              <span class="badge" id="badge-test-motor_left" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">AIN1: 27 • AIN2: 26</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_MOTOR_LEFT')">Pulse 0.5s</button>
            </div>
          </div>

          <!-- 6. Motor Driver Kanan -->
          <div class="diag-card" id="card-test-motor_right">
            <div class="diag-head">
              <span style="font-weight: 700; font-size: 11.5px; color: #F1F5F9;">Motor Kanan (DRV8833)</span>
              <span class="badge" id="badge-test-motor_right" style="background: #1F2937; color: #94A3B8;">Standby</span>
            </div>
            <div class="diag-actions">
              <span style="font-size: 10.5px; color: #64748B; font-family: monospace;">BIN1: 25 • BIN2: 33 (STBY 23)</span>
              <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="runHwTest('TEST_MOTOR_RIGHT')">Pulse 0.5s</button>
            </div>
          </div>
        </div>

        <!-- Real-time Diagnostic Log Console -->
        <div style="margin-top: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
            <span style="font-size: 10px; font-weight: 700; color: #64748B; text-transform: uppercase; letter-spacing: 0.05em;">Console Respon Hardware</span>
            <span style="font-size: 10px; color: #38BDF8; cursor: pointer;" onclick="clearDiagLog()">Bersihkan Log</span>
          </div>
          <div class="diag-log" id="diag-console-log">
            <div class="diag-log-entry">
              <span class="diag-log-time">[00:00:00]</span> Sistem siap. Tekan salah satu uji hardware di atas untuk memulai diagnostik.
            </div>
          </div>
        </div>
      </div>
    </div>

  </main>

  <footer>
    Capstone Design Kelompok 12 • S1 Teknik Elektro Universitas Negeri Malang<br>
    Platform IoT & Dashboard MazeBot EduKit v1.0.0
  </footer>

  <script>
    /* State Management */
    let socket = null;
    let simulationMode = false;
    let restMode = false;
    let restPollInterval = null;
    let simInterval = null;
    let robotState = {
      status: "IDLE",
      timer_ms: 0,
      sensors: { left_cm: 25.0, front_cm: 30.0, right_cm: 5.0, line: 0 },
      maze: { grid_count: 0, raw_array: [], optimized_array: [] },
      config: { pwm: 180, target_dist: 5.0 }
    };
    
    // ESP32 REST API Configuration
    const ESP32_CONFIG = {
      baseUrl: 'http://192.168.4.1',  // Default SoftAP IP
      endpoints: {
        data: '/api/data',
        drive: '/api/drive',
        stop: '/api/stop',
        save: '/api/save'
      },
      pollIntervalMs: 200  // 5 Hz polling
    };

    /* Switch Tabs */
    function switchView(viewName) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));
      
      document.getElementById('view-' + viewName).classList.add('active');
      const tabs = document.querySelectorAll('.nav-tab');
      if (viewName === 'dashboard') tabs[0].classList.add('active');
      if (viewName === 'schematic') tabs[1].classList.add('active');
    }

    /* WebSocket Connection Handling */
    function initWebSocket() {
      const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsHost = window.location.host || '192.168.4.1';
      const wsUrl = `${wsProtocol}//${wsHost}/ws`;

      updateBadge('reconnect', 'CONNECTING...');

      try {
        socket = new WebSocket(wsUrl);

        socket.onopen = () => {
          console.log('[WS] Connected to ESP32 / Server');
          updateBadge('online', 'CONNECTED');
          setSimulation(false);
        };

        socket.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            applyTelemetry(data);
          } catch (e) {
            console.error('[WS] Parse error', e);
          }
        };

        socket.onerror = (err) => {
          console.warn('[WS] Socket error, fallback to sim if standalone', err);
        };

        socket.onclose = () => {
          console.log('[WS] Disconnected, trying HTTP REST Fallback');
          updateBadge('reconnect', 'TRY REST API...');
          
          // Test REST API connectivity
          fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.data}`)
            .then(res => res.json())
            .then(data => {
              console.log('[REST] Connected to ESP32 API!');
              restMode = true;
              updateBadge('online', 'ESP32 (REST)');
              startRestPolling();
            })
            .catch(() => {
              restMode = false;
              updateBadge('offline', 'OFFLINE');
              setTimeout(() => {
                if (!simulationMode && !restMode) initWebSocket();
              }, 3000);
            });
        };
      } catch (err) {
        updateBadge('offline', 'SIM ONLY');
        setSimulation(true);
      }
    }

    let initializedMotor = false;

    function updateWheelPWM() {
      const l = document.getElementById('pwm-left-slider').value;
      const r = document.getElementById('pwm-right-slider').value;
      document.getElementById('pwm-left-val').textContent = l;
      document.getElementById('pwm-right-val').textContent = r;
    }

    async function simpanPWMMotor() {
      const l = document.getElementById('pwm-left-slider').value;
      const r = document.getElementById('pwm-right-slider').value;
      const msg = document.getElementById('motor-save-msg');
      msg.textContent = 'Menyimpan ke NVS ESP32...';
      try {
        const res = await fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.save}?l=${l}&r=${r}`, { method: 'POST' });
        if (res.ok) {
          msg.textContent = `✓ Tersimpan di NVS: L=${l}, R=${r}`;
          msg.style.color = '#34D399';
        } else {
          throw new Error();
        }
      } catch (e) {
        msg.textContent = 'Gagal menyimpan ke ESP32';
        msg.style.color = '#F87171';
      }
    }

    async function kalibrasiTCRT(warna) {
      const msg = document.getElementById('tcrt-feedback-msg');
      msg.textContent = `Membaca sampel ${warna.toUpperCase()} (48x)...`;
      try {
        const res = await fetch(`${ESP32_CONFIG.baseUrl}/api/tcrt/${warna}`, { method: 'POST' });
        const d = await res.json();
        msg.textContent = d.pesan || 'Sampel tercatat.';
        msg.style.color = d.ok ? '#34D399' : '#FBBF24';
      } catch (e) {
        msg.textContent = 'Gagal mengirim kalibrasi ke ESP32';
        msg.style.color = '#F87171';
      }
    }

    async function testWheelDrive(mode) {
      const l = document.getElementById('pwm-left-slider').value;
      const r = document.getElementById('pwm-right-slider').value;
      try {
        await fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.drive}?mode=${mode}&l=${l}&r=${r}`, { method: 'POST' });
      } catch (e) {
        console.warn('Drive test error:', e);
      }
    }

    async function stopAllMotors() {
      try {
        await fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.stop}`, { method: 'POST' });
      } catch (e) {
        console.warn('Stop error:', e);
      }
    }

    function startRestPolling() {
      if (restPollInterval) clearInterval(restPollInterval);
      restPollInterval = setInterval(() => {
        if (!restMode) return;
        fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.data}`)
          .then(res => res.json())
          .then(data => {
            // Update Ultrasonic Radar & Robot Status
            const mapped = {
              status: (data.mode || "IDLE").toUpperCase(),
              sensors: {
                left_cm: data.kiri !== null ? data.kiri : 0,
                front_cm: data.depan !== null ? data.depan : 0,
                right_cm: data.kanan !== null ? data.kanan : 0,
                line: data.garisHitam ? 1 : 0
              }
            };
            applyTelemetry(mapped);

            // Update TCRT5000 Live Panel
            const elAdc = document.getElementById('tcrt-adc-live');
            if (elAdc && data.adc !== undefined) elAdc.textContent = data.adc;
            const elPutih = document.getElementById('tcrt-sampel-putih');
            if (elPutih && data.putih !== undefined) elPutih.textContent = data.putih;
            const elHitam = document.getElementById('tcrt-sampel-hitam');
            if (elHitam && data.hitam !== undefined) elHitam.textContent = data.hitam;
            const elAmbang = document.getElementById('tcrt-ambang-batas');
            if (elAmbang && data.ambang !== undefined) elAmbang.textContent = data.ambang;
            const elSelisih = document.getElementById('tcrt-selisih-adc');
            if (elSelisih && data.putih !== undefined && data.hitam !== undefined) {
              elSelisih.textContent = Math.abs(data.hitam - data.putih);
            }

            const pill = document.getElementById('tcrt-status-pill');
            if (pill) {
              if (!data.tcrtValid) {
                pill.textContent = 'BELUM VALID (SELISIH < 20)';
                pill.style.background = '#374151';
                pill.style.color = '#94A3B8';
              } else if (data.garisHitam) {
                pill.textContent = 'GARIS HITAM / FINISH';
                pill.style.background = '#854D0E';
                pill.style.color = '#FEF08A';
              } else {
                pill.textContent = 'PERMUKAAN PUTIH';
                pill.style.background = '#166534';
                pill.style.color = '#DCFCE7';
              }
            }

            // Sync saved PWM to sliders once on connect
            if (!initializedMotor && data.savedKiri !== undefined && data.savedKanan !== undefined) {
              const slL = document.getElementById('pwm-left-slider');
              const slR = document.getElementById('pwm-right-slider');
              if (slL) slL.value = data.savedKiri;
              if (slR) slR.value = data.savedKanan;
              updateWheelPWM();
              initializedMotor = true;
            }
          })
          .catch(e => {
            console.warn('[REST Poll Error]', e);
            updateBadge('offline', 'DISCONNECTED');
          });
      }, ESP32_CONFIG.pollIntervalMs);
    }

    function updateBadge(status, text) {
      const badge = document.getElementById('ws-badge');
      const label = document.getElementById('ws-status-text');
      badge.className = `badge badge-${status}`;
      label.innerText = text;
    }

    /* Outbound Commands (FR-C, FR-D) */
    function sendCmd(cmd) {
      const payload = { cmd: cmd };
      sendPayload(payload);

      if (simulationMode) {
        handleSimCommand(payload);
      } else if (restMode) {
        handleRestCommand(cmd);
      }
    }

    let driveInterval = null;

    function startContinuousDrive(dir) {
      if (driveInterval) clearInterval(driveInterval);
      sendDrive(dir);
      driveInterval = setInterval(() => {
        sendDrive(dir);
      }, 200);
    }

    function stopContinuousDrive() {
      if (driveInterval) {
        clearInterval(driveInterval);
        driveInterval = null;
      }
      sendDrive('STOP');
    }

    function sendDrive(dir) {
      const payload = { cmd: "DRIVE", dir: dir };
      sendPayload(payload);
      
      if (simulationMode) {
        console.log('[SIM] Drive command:', dir);
      } else if (restMode) {
        handleRestDrive(dir);
      }
    }

    function handleRestCommand(cmd) {
      const l = parseInt(document.getElementById('pwm-left-slider').value) || 255;
      const r = parseInt(document.getElementById('pwm-right-slider').value) || 244;
      if (cmd === 'START_MAPPING') {
        fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.drive}?mode=maju&l=${l}&r=${r}`, { method: 'POST' })
          .catch(e => console.error('[REST Error]', e));
      } else if (cmd === 'ESTOP' || cmd === 'RESET') {
        fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.stop}`, { method: 'POST' })
          .catch(e => console.error('[REST Error]', e));
      }
    }

    function handleRestDrive(dir) {
      const l = parseInt(document.getElementById('pwm-left-slider').value) || 255;
      const r = parseInt(document.getElementById('pwm-right-slider').value) || 244;
      let mode = 'stop';

      switch(dir) {
        case 'FORWARD': mode = 'maju'; break;
        case 'BACKWARD': mode = 'mundur'; break;
        case 'LEFT': mode = 'belok_kiri'; break;
        case 'RIGHT': mode = 'belok_kanan'; break;
        case 'STOP': mode = 'stop'; break;
      }

      if (mode === 'stop') {
        fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.stop}`, { method: 'POST' })
          .catch(e => console.error('[REST Error]', e));
      } else {
        fetch(`${ESP32_CONFIG.baseUrl}${ESP32_CONFIG.endpoints.drive}?mode=${mode}&l=${l}&r=${r}`, { method: 'POST' })
          .catch(e => console.error('[REST Error]', e));
      }
    }

    function saveConfig() {
      simpanPWMMotor();
    }

    function sendPayload(obj) {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(obj));
        console.log('[WS Outbound]', obj);
      } else {
        console.log('[Local Outbound]', obj);
      }
    }

    /* Telemetry Application & UI Updates */
    function applyTelemetry(data) {
      if (!data) return;

      // Status
      if (data.status) {
        robotState.status = data.status;
        const pill = document.getElementById('robot-status-pill');
        pill.innerText = data.status;
        
        if (data.status === 'MAPPING') pill.style.background = '#1E3A8A';
        else if (data.status === 'SOLVING') pill.style.background = '#065F46';
        else if (data.status === 'STOPPED') pill.style.background = '#7F1D1D';
        else pill.style.background = '#312E81';
      }

      // Stopwatch
      if (typeof data.timer_ms !== 'undefined') {
        robotState.timer_ms = data.timer_ms;
        document.getElementById('stopwatch-display').innerText = formatTimer(data.timer_ms);
      }

      // Sensors
      if (data.sensors) {
        updateSensor('left', data.sensors.left_cm);
        updateSensor('front', data.sensors.front_cm);
        updateSensor('right', data.sensors.right_cm);

        // Line sensor (0 = putih/aman, 1 = hitam/finish)
        const lineBadge = document.getElementById('line-sensor-badge');
        if (data.sensors.line === 1) {
          lineBadge.className = 'line-pill line-black';
          lineBadge.innerText = '1 (HITAM / FINISH)';
        } else {
          lineBadge.className = 'line-pill line-white';
          lineBadge.innerText = '0 (PUTIH / BEBAS)';
        }
      }

      // Maze Memory
      if (data.maze) {
        if (typeof data.maze.grid_count !== 'undefined') {
          document.getElementById('grid-step-count').innerText = data.maze.grid_count;
        }
        renderPath('raw-path-container', data.maze.raw_array || []);
        renderPath('opt-path-container', data.maze.optimized_array || []);
      }
    }

    function updateSensor(pos, val) {
      const elVal = document.getElementById('val-' + pos);
      const elBox = document.getElementById('box-' + pos);
      if (!elVal || !elBox) return;

      const num = parseFloat(val).toFixed(1);
      elVal.innerText = num + ' cm';

      elBox.classList.remove('dist-safe', 'dist-warn', 'dist-danger');
      if (num < 5.0) {
        elBox.classList.add('dist-danger'); // Merah (< 5 cm)
      } else if (num <= 15.0) {
        elBox.classList.add('dist-warn');   // Kuning (5-15 cm)
      } else {
        elBox.classList.add('dist-safe');   // Hijau (> 15 cm)
      }
    }

    function renderPath(containerId, arr) {
      const container = document.getElementById(containerId);
      if (!arr || arr.length === 0) {
        container.innerHTML = '<span class="empty-state">Belum ada data...</span>';
        return;
      }

      let html = '';
      arr.forEach((turn, idx) => {
        html += `<span class="turn-badge turn-${turn}">${turn}</span>`;
        if (idx < arr.length - 1) {
          html += `<span class="arrow-sep">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 14px; height: 14px; display: inline-block; vertical-align: middle;" aria-hidden="true">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </span>`;
        }
      });
      container.innerHTML = html;
    }

    function formatTimer(ms) {
      const totalSec = Math.floor(ms / 1000);
      const minutes = Math.floor(totalSec / 60);
      const seconds = totalSec % 60;
      const hundredths = Math.floor((ms % 1000) / 10);

      const mm = String(minutes).padStart(2, '0');
      const ss = String(seconds).padStart(2, '0');
      const hh = String(hundredths).padStart(2, '0');
      return `${mm}:${ss}.${hh}`;
    }

    function updateTuningUI() {
      const pwm = document.getElementById('pwm-slider').value;
      const dist = (document.getElementById('dist-slider').value / 10.0).toFixed(1);
      document.getElementById('pwm-display').innerText = pwm;
      document.getElementById('dist-display').innerText = dist + ' cm';
    }

    /* Simulation Engine (For Test / Classroom Demo without ESP32) */
    function setSimulation(enable) {
      simulationMode = enable;
      const btn = document.getElementById('sim-toggle-btn');
      if (simulationMode) {
        btn.innerText = 'SIM: ON';
        btn.style.background = '#065F46';
        btn.style.color = '#A7F3D0';
        startSimulationLoop();
      } else {
        btn.innerText = 'SIM: OFF';
        btn.style.background = '#374151';
        btn.style.color = '#D1D5DB';
        if (simInterval) clearInterval(simInterval);
      }
    }

    document.getElementById('sim-toggle-btn').addEventListener('click', () => {
      setSimulation(!simulationMode);
    });

    function handleSimCommand(payload) {
      if (payload.cmd === 'START_MAPPING') {
        robotState.status = 'MAPPING';
        robotState.timer_ms = 0;
        robotState.maze.grid_count = 0;
        robotState.maze.raw_array = ['L'];
        robotState.maze.optimized_array = ['L'];
      } else if (payload.cmd === 'START_SPEEDRUN') {
        robotState.status = 'SOLVING';
        robotState.timer_ms = 0;
      } else if (payload.cmd === 'ESTOP') {
        robotState.status = 'STOPPED';
      } else if (payload.cmd === 'RESET') {
        robotState.status = 'IDLE';
        robotState.timer_ms = 0;
        robotState.maze.grid_count = 0;
        robotState.maze.raw_array = [];
        robotState.maze.optimized_array = [];
        robotState.sensors.line = 0;
      }
    }

    /* LSRB Reduction Algorithm Implementation */
    function optimizeLSRB(path) {
      if (path.length < 3) return path.slice();
      let optimized = [];
      let i = 0;
      while (i < path.length) {
        if (i <= path.length - 3 && path[i + 1] === 'U') {
          const rule = path[i] + 'U' + path[i + 2];
          let repl = null;
          if (rule === 'LUL') repl = 'S';
          else if (rule === 'LUS') repl = 'R';
          else if (rule === 'RUL') repl = 'U';
          else if (rule === 'SUL') repl = 'R';
          else if (rule === 'SUS') repl = 'U';
          else if (rule === 'LUR') repl = 'U';

          if (repl) {
            optimized.push(repl);
            i += 3;
            continue;
          }
        }
        optimized.push(path[i]);
        i++;
      }
      return optimized;
    }

    function startSimulationLoop() {
      if (simInterval) clearInterval(simInterval);
      
      const turns = ['L', 'S', 'L', 'U', 'L', 'R', 'S', 'L'];
      let turnIdx = 0;

      simInterval = setInterval(() => {
        if (robotState.status === 'MAPPING' || robotState.status === 'SOLVING') {
          robotState.timer_ms += 100;

          // Simulasi nilai ultrasonik
          robotState.sensors.left_cm = 4.8 + Math.sin(Date.now() / 400) * 1.5;
          robotState.sensors.front_cm = 18.0 + Math.cos(Date.now() / 500) * 12.0;
          robotState.sensors.right_cm = 22.0 + Math.sin(Date.now() / 600) * 5.0;

          // Step count & turn generation
          if (robotState.timer_ms % 2000 === 0 && robotState.status === 'MAPPING') {
            robotState.maze.grid_count++;
            if (turnIdx < turns.length) {
              robotState.maze.raw_array.push(turns[turnIdx++]);
              robotState.maze.optimized_array = optimizeLSRB(robotState.maze.raw_array);
            }
          }

          // Finish Line Simulation at 16s
          if (robotState.timer_ms >= 16000) {
            robotState.sensors.line = 1;
            robotState.status = 'STOPPED';
          }
        }

        applyTelemetry(robotState);
      }, 100);
    }

    // Initialize on load
    window.addEventListener('DOMContentLoaded', () => {
      initWebSocket();
      // Auto enable sim if opened directly from static file or offline
      setTimeout(() => {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
          setSimulation(true);
        }
      }, 800);
    });

    /* ============================================================================
       INTERACTIVE SCHEMATIC & HARDWARE TESTER LOGIC
       ============================================================================ */
    let activeSchematicFilter = 'all';
    const schematicNodeMap = {
      'all': ['node-esp32'],
      'us_front': ['node-us_front', 'node-esp32'],
      'us_left': ['node-us_left', 'node-esp32'],
      'us_right': ['node-us_right', 'node-esp32'],
      'line': ['node-line', 'node-esp32'],
      'motors': ['node-motors', 'node-esp32']
    };
    const wireGroupMap = {
      'all': ['wires-us_left', 'wires-us_front', 'wires-us_right', 'wires-line', 'wires-motors'],
      'us_front': ['wires-us_front'],
      'us_left': ['wires-us_left'],
      'us_right': ['wires-us_right'],
      'line': ['wires-line'],
      'motors': ['wires-motors']
    };
    const detailContent = {
      'all': {
        title: 'Semua Komponen Terkoneksi',
        tag: 'Ringkasan Sistem',
        body: 'Sistem menggunakan mikrokontroler ESP32 DevKit V1 yang mengelola 3 modul ultrasonik HC-SR04 untuk navigasi dinding labirin (Wall-Following), 1 sensor TCRT5000 untuk deteksi garis stop/finish, dan modul dual motor DRV8833 dengan modulasi PWM.'
      },
      'us_front': {
        title: 'Ultrasonik Depan (HC-SR04)',
        tag: 'Sensor Jarak Dinding',
        body: 'Pinout: Trig ➔ GPIO 4 (Output), Echo ➔ GPIO 17 (Input via Interrupt echoISR).<br>Fungsi: Mengukur jarak dinding depan untuk kontrol kecepatan & pencegahan tabrakan.<br>Rentang efektif: 2 cm – 400 cm. Kalibrasi sensor 10.0 / 9.1.'
      },
      'us_left': {
        title: 'Ultrasonik Kiri (HC-SR04)',
        tag: 'Sensor Wall-Follow',
        body: 'Pinout: Trig ➔ GPIO 19 (Output), Echo ➔ GPIO 18 (Input via Interrupt echoISR).<br>Fungsi: Referensi utama algoritma Wall-Following (Left Hand Rule). Robot menjaga jarak ~5 cm dari dinding kiri.'
      },
      'us_right': {
        title: 'Ultrasonik Kanan (HC-SR04)',
        tag: 'Sensor Koreksi Jalan',
        body: 'Pinout: Trig ➔ GPIO 14 (Output), Echo ➔ GPIO 13 (Input via Interrupt echoISR).<br>Fungsi: Deteksi dinding kanan untuk koreksi & deteksi persimpangan labirin.'
      },
      'line': {
        title: 'TCRT5000 Line Tracker',
        tag: 'Sensor Garis Finish',
        body: 'Pinout: DO/A0 ➔ GPIO 32 (ADC1_CH4 12-bit).<br>Fungsi: Mendeteksi garis hitam finish/stop menggunakan refleksi sinar inframerah.<br>Logika: 0 = Jalur Putih, 1 = Garis Hitam.'
      },
      'motors': {
        title: 'Dual Motor Driver DRV8833',
        tag: 'Aktuator Gerak',
        body: 'Pinout:<br>• Motor Kiri: AIN1=GPIO 27, AIN2=GPIO 26 (PWM 18kHz)<br>• Motor Kanan: BIN1=GPIO 25, BIN2=GPIO 33 (PWM 18kHz)<br>• Standby: STBY=GPIO 23 (Active HIGH, auto-sleep saat STOP)<br>Fungsi: H-bridge 2-channel, drive 2 motor DC terpisah dengan soft-transition & fail-safe 650ms.'
      }
    };

    function filterSchematic(filter) {
      activeSchematicFilter = filter;

      // Update filter pills
      document.querySelectorAll('.filter-pill').forEach(el => {
        el.classList.remove('active');
        if (el.getAttribute('onclick')?.includes(filter) || 
            (filter === 'all' && el.textContent === 'Semua Komponen')) {
          el.classList.add('active');
        }
      });

      // Dim/Show nodes
      document.querySelectorAll('.svg-node').forEach(node => {
        const id = node.id;
        const isVisible = schematicNodeMap[filter].includes(id);
        node.classList.toggle('node-dimmed', !isVisible);
        if (isVisible) node.style.transform = 'scale(1.02)';
        else node.style.transform = 'scale(1)';
      });

      // Highlight/Show wires
      document.querySelectorAll('.svg-wire').forEach(wire => {
        const groupId = wire.closest('g')?.id;
        const isVisible = wireGroupMap[filter].includes(groupId);
        wire.classList.toggle('wire-active', isVisible);
        if (!isVisible) wire.style.opacity = '0.2';
        else wire.style.opacity = '1';
      });

      // Update detail card
      const d = detailContent[filter];
      document.getElementById('detail-title').innerText = d.title;
      document.getElementById('detail-tag').innerText = d.tag;
      document.getElementById('detail-body').innerHTML = d.body;
    }

    function runHwTest(testCmd) {
      const log = document.getElementById('diag-console-log');
      const time = new Date().toLocaleTimeString('id-ID', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
      
      // Send command
      sendPayload({ cmd: testCmd });
      
      // Update badge to testing
      const badgeId = 'badge-test-' + testCmd.replace('TEST_', '').toLowerCase();
      const cardId = 'card-' + badgeId.replace('badge-test-', 'test-');
      const badge = document.getElementById(badgeId);
      const card = document.getElementById(cardId);
      if (badge) { badge.innerText = 'Menguji...'; badge.style.background = '#374151'; badge.style.color = '#FBBF24'; }
      if (card) card.classList.add('active-test');

      // Log sent command
      log.insertAdjacentHTML('afterbegin', `<div class="diag-log-entry"><span class="diag-log-time">[${time}]</span> ▶ CMD: ${testCmd}</div>`);
      
      // Listen for test_result (handled in applyTelemetry-like way)
      // We'll patch the message handler to capture test_result
    }

    function runFullSelfTest() {
      const log = document.getElementById('diag-console-log');
      const time = new Date().toLocaleTimeString('id-ID', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
      
      sendPayload({ cmd: 'TEST_ALL' });
      
      log.insertAdjacentHTML('afterbegin', `<div class="diag-log-entry"><span class="diag-log-time">[${time}]</span> ▶ <span style="color:#F59E0B;">AUTO SELF-TEST DIMULAI</span> — menguji seluruh hardware secara berurutan...</div>`);
      
      // Activate all test cards
      document.querySelectorAll('.diag-card').forEach(card => card.classList.add('active-test'));
      document.querySelectorAll('.badge[id^="badge-test-"]').forEach(b => { b.innerText = 'Menguji...'; b.style.background = '#374151'; b.style.color = '#FBBF24'; });
    }

    function clearDiagLog() {
      document.getElementById('diag-console-log').innerHTML = `
        <div class="diag-log-entry">
          <span class="diag-log-time">[${new Date().toLocaleTimeString('id-ID', {hour12:false, hour:'2-digit',minute:'2-digit',second:'2-digit'})}]</span> Log dibersihkan. Siap untuk sesi diagnostik baru.
        </div>`;
    }

    // Patch socket.onmessage to handle test_result
    const originalOnMessage = socket?.onmessage;
    function setupTestResultHandler() {
      if (socket) {
        socket.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            
            // Handle test_result from server
            if (data.type === 'test_result') {
              const log = document.getElementById('diag-console-log');
              const time = new Date().toLocaleTimeString('id-ID', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
              
              const badgeId = 'badge-test-' + data.test;
              const cardId = 'card-test-' + data.test;
              const badge = document.getElementById(badgeId);
              const card = document.getElementById(cardId);
              
              if (data.success) {
                log.insertAdjacentHTML('afterbegin', `<div class="diag-log-entry"><span class="diag-log-time">[${time}]</span> <span class="diag-log-ok">✓ ${data.test.toUpperCase()}</span> — ${data.value} ${data.unit} — ${data.message}</div>`);
                if (badge) { badge.innerText = 'OK'; badge.style.background = '#064E3B'; badge.style.color = '#34D399'; }
                if (card) { card.classList.remove('active-test'); card.style.borderColor = '#10B981'; }
              } else {
                log.insertAdjacentHTML('afterbegin', `<div class="diag-log-entry"><span class="diag-log-time">[${time}]</span> <span style="color:#F87171;">✗ ${data.test.toUpperCase()}</span> — ${data.message || 'Gagal'}</div>`);
                if (badge) { badge.innerText = 'GAGAL'; badge.style.background = '#7F1D1D'; badge.style.color = '#F87171'; }
                if (card) { card.classList.remove('active-test'); card.style.borderColor = '#EF4444'; }
              }
              
              if (data.test === 'all_complete') {
                log.insertAdjacentHTML('afterbegin', `<div class="diag-log-entry"><span class="diag-log-time">[${time}]</span> <span style="color:#F59E0B; font-weight:bold;">■ SELURUH SELF-TEST SELESAI</span> — ${data.message}</div>`);
                document.querySelectorAll('.diag-card').forEach(card => { card.classList.remove('active-test'); card.style.borderColor = 'var(--border)'; });
                document.querySelectorAll('.badge[id^="badge-test-"]').forEach(b => { b.innerText = 'OK'; b.style.background = '#064E3B'; b.style.color = '#34D399'; });
              }
            } else {
              applyTelemetry(data);
            }
          } catch (e) {
            console.error('[WS] Parse error', e);
          }
        };
      }
    }

    // Call after WS init
    const originalInitWS = initWebSocket;
    initWebSocket = function() {
      originalInitWS.call(this);
      // Override onmessage after socket created
      setTimeout(setupTestResultHandler, 100);
    };
  </script>
</body>
</html>

)rawliteral";

#endif // WEB_PAGE_H
